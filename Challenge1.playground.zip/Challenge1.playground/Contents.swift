// Create a program that uses a for loop to print out all the numbers from 1 to 10.
for numbers in 1...10{
    print(numbers)
}

// Write a program that uses a while loop to print out all the even numbers from 2 to 20.
var x = 2
while x <= 20{
    
  print(x)
  x += 1
}

// Write a program that uses a switch statement to determine whether a given number is positive, negative, or zero.

var cheakNumber = -18

switch cheakNumber {
case 0:
    print("Zero")
case 1... :
    print("Positive Number")
case ..<1 :
    print("Negative Number")
default:
    print("Anything")
}

// Write a program that uses an if statement to check if a given number is even or odd. If the number is even, print "even"; if it's odd, print "odd".
var firstNumber = 4
if (firstNumber % 2 == 0){
    print("even ..")
}
    else{
        
        print("odd")
    }
// Write a program that uses a for-in loop to iterate over a dictionary and print out all the key-value pairs.
var countries =  ["US":"UnitedStates",  "SA":"Saudia Arabia", "UK":"United Kingdom"]
for i in countries{
    print(i)
}
//Create a program that uses a for-in loop to iterate over a range of numbers and print out all the numbers that are divisible by 3.

var arr = [33,22,1332]
for d in arr {
  if d % 3 == 0 {
    print(d)
  }
}

//Write a function that takes an array of strings as an argument and returns a new array that contains only the strings that have more than 4 characters.

func languages(array1:[String]) -> [String] {
    var array2:[String] = []
    for item in array1 {
        if item.count > 4 {
            array2.append(item)
        }
    }
    print(array2)
    return array2
}
languages(array1: ["Python", "Ruby", "Swift","java"])
