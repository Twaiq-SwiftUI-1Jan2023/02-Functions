//: [Previous](@previous)

import Foundation


//Write a program that uses a while loop to print out all the even numbers from 2 to 20.
var num1 = 2
var num2 = 20
while num1 <= num2 {
    if num1 % 2==0{
        print(num1)
    }
       num1+=1
}
