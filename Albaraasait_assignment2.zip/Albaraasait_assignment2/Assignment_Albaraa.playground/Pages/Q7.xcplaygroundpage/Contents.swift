//: [Previous](@previous)

import Foundation

for i in 1...50 {
    if i % 3 == 0{
        print(i)
    }
}
