import UIKit

//Create a program that uses a for loop to print out all the numbers from 1 to 10.
for i in 1...10 {
    print(i)
}
