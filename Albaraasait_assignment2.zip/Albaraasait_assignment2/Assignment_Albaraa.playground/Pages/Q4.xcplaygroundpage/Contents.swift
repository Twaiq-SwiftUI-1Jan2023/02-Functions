//: [Previous](@previous)

import Foundation

//Write a program that uses a switch statement to determine whether a given number is positive, negative, or zero.
func switchnumber (number : Int)  {
    
    switch number {
        case 0 :print("zero")
        case ...0: print("\(number) is a negative number.")
        case 0...9: print("\(number) is a positive number.")
        default: break
    }
}
switchnumber(number: -9)

